const config = {
  apiBaseUrl:'http://www.51zrcf.com/v/tmp/',
  ns:'com.51zrcf.s'
}

export default {...config};
