import * as httpservice from '../services/httpservice';
export default {
  namespace: 'order',
  state: {
    currentData:{
      payway:'WCP',
      addressId:0
    },
    orderMap:{}
  },
  reducers: {
    // togglePayway(state,{payway}){
    //   return {...state,currentPayway:payway}
    // },
    init(state,{payload}){
      return {...state,currentData:{...state.currentData,...payload}}
    },
    syncCurrentData(state,{payload}){
      return {...state,currentData:{...state.currentData,...payload}}
    },
    selectAddress(state,{index}){
      return {...state,currentData:{...state.currentData,addressId:index}}
    },
    loadOrderList(state,{orderMap}){
      return {...state,orderMap:orderMap};
    }
  },
  effects: {
    *fetch({id},{call,put}) {
      const {data,header} = yield call(httpservice.post, {url:'getQuotePriceForCategore',param:{id:id}});
      yield put({ type: 'init',userInfo:userInfo});
    },
    *list({},{call,put}) {
      const {data,header} = yield call(httpservice.post, {url:'engineerOrderOperation',param:{ac:'getWaitingList'}});
      yield put({ type: 'loadWaitingList',orderMap:data.data||{}});
    },
  },
  subscriptions: {
    setup({dispatch, history}) {
      history.listen(({pathname, query}) => {
        if (pathname === '/indexpage' || pathname === '/') {
          dispatch({type: 'list'});
        }
      });

    },
  },
};
